import 'package:flutter/material.dart';
import 'dart:io';
const Color primeryColor = Color(0xffFF0000);